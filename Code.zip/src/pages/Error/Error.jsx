import React from 'react';

const Error = () =>{
	return(
		<div className='text-center mt-[108px] '>
			<h1 className='text-[64px]'>Error 404</h1>
		</div>
	);
};

export default Error;